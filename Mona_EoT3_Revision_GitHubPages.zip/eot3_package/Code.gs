/**
 * EoT3 Interactive Revision — Google Sheet report receiver
 * ----------------------------------------------------------
 * Setup:
 * 1. Create (or open) a Google Sheet for this — e.g. "EoT3 Revision Reports".
 * 2. In that Sheet: Extensions → Apps Script.
 * 3. Delete any starter code and paste this whole file in.
 * 4. Click "Deploy" → "New deployment" → type: Web app.
 *      - Execute as: Me
 *      - Who has access: Anyone
 * 5. Click Deploy, authorize when asked, then copy the Web App URL
 *    (it ends in /exec).
 * 6. Paste that URL into "Connect Your Google Sheet" in Teacher Tools
 *    on the revision page, then click "Test Connection".
 */

function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Reports');
  if (!sheet) {
    sheet = SpreadsheetApp.getActiveSpreadsheet().insertSheet('Reports');
  }
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(['Student', 'Grade', 'Section', 'Topic', 'Score', 'Total', 'Percent', 'Date']);
  }

  var data = JSON.parse(e.postData.contents);

  sheet.appendRow([
    data.student || '',
    data.grade || '',
    data.section || '',
    data.topic || '',
    data.score,
    data.total,
    data.pct,
    data.date || new Date().toISOString()
  ]);

  return ContentService
    .createTextOutput(JSON.stringify({ status: 'ok' }))
    .setMimeType(ContentService.MimeType.JSON);
}

function doGet(e) {
  return ContentService
    .createTextOutput(JSON.stringify({ status: 'EoT3 Revision Apps Script is connected and ready.' }))
    .setMimeType(ContentService.MimeType.JSON);
}
