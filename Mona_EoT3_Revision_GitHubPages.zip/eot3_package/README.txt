# Mona's English Practice Hub — Hosting on GitHub Pages

This gives you one permanent link, branded with your name, just for your
students — the same way Aliya's site works (hers is
aliyashah13.com → really a GitHub Pages site behind a custom domain).

## What's in this folder
- `index.html` — the revision page (Vocabulary, Grammar, Reading + Teacher Tools)
- `Code.gs` — optional Google Apps Script so results also land in a Google Sheet

---

## Step 1 — Create a GitHub account (skip if you already have one)
Go to https://github.com/join and sign up — it's free.

## Step 2 — Create a new repository
1. Click the **+** icon (top right) → **New repository**.
2. Repository name — this becomes part of your link, so pick something like:
   `mona-eot3` or `english-practice-hub`
3. Keep it **Public**.
4. Tick **"Add a README file"**, then click **Create repository**.

## Step 3 — Upload your page
1. In your new repository, click **Add file → Upload files**.
2. Drag in `index.html` from this folder.
3. Scroll down, click **Commit changes**.

## Step 4 — Turn on GitHub Pages
1. In the repository, go to **Settings → Pages** (left sidebar).
2. Under "Build and deployment" → Source: select **Deploy from a branch**.
3. Branch: select **main**, folder: **/ (root)** → click **Save**.
4. Wait about a minute, then refresh — GitHub shows your live link at the top,
   something like:

   `https://<your-username>.github.io/mona-eot3/`

That's your link — share it with your students exactly like Aliya shares hers.
(You can also point a custom domain at it later in the same Settings → Pages
screen, if you ever buy one like she did.)

## Step 5 — Making updates later
Whenever you want to change the page (e.g. you ask Claude to add more
content), just re-upload the new `index.html` the same way (Add file →
Upload files → Commit changes) and it overwrites the old one — your link
stays exactly the same.

---

## Optional — Reports into your own Google Sheet
1. Go to https://sheets.google.com and create a new blank sheet, e.g.
   "EoT3 Revision Reports".
2. **Extensions → Apps Script**, delete the placeholder code, paste in
   everything from `Code.gs`.
3. **Deploy → New deployment** → type: **Web app** → Execute as: **Me** →
   Who has access: **Anyone** → **Deploy**. Approve the permissions Google
   asks for, then copy the URL (ends in `/exec`).
4. On your live GitHub Pages link: **Teacher Tools → Connect Your Google
   Sheet** → paste the URL → **Save URL** → **Test Connection**.

From then on, every quiz a student completes is logged automatically in
your Sheet — student name, grade, section, topic, score, percentage, date.

---

## Notes
- Everything you add in Teacher Tools (words, quiz questions, passages,
  certificate details) is part of the page for all your students — there's
  no separate teacher logins, by design, since this is just for you.
- Student reports are visible to you in Teacher Tools on the page, and in
  your Google Sheet if connected — nowhere else.
